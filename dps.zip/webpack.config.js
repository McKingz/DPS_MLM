// webpack.config.js
const config = {
    // Other configurations...
    devtool: 'source-map', // Ensure this line is present
};

export default config;